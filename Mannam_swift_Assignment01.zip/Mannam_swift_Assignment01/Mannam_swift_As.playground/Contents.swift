import UIKit

//1st question
print("Swift programming language first version was introduced in the year 2014.\n");
print("----------------------")
//end of 1st question

//2nd question
var pi:Double = 3.14;
var radius = 7.5;
var Circumference = 2*pi*radius;
print("\n",Circumference ,"\n");
print("----------------------")
//end of 2nd question

//3rd question
var a = 98.8;
var celcius = (a-32.0)*(5.0/9.0);
print("\nFahrenheit:" ,a,"F\n"+"Celcius:  ",round(celcius*100)/100,"C \n");
print("----------------------")
//end of 3rd question

//4th question
print("\nHello everyone,I am Sandeep Mannam,I am from Kandukuru,Andhra Pradesh.",terminator: " ")
print("I am currently doing my Master's in Applied Computer Science and also working as a Graduate Assistant.")
print("My career goal is to become an enterprenuer.\n")
print("----------------------")
//end of 4th question

//5th question
print("\nSwift is a powerful and intuitive proramming language for ios,ipadOS,macOS,and watchOS.\rWriting Swift code is interactive and fun, the syntax is concise yet expressive, and Swift includes modern features   developers love.\rSwift code is safe by design and produces software that runs lighting-fast.\n")
print("----------------------")
//end of 5th question

//6th question
var number:Int=994845
var numString=String(number);
print("\nThe number",number,"has",numString.count,"digits.\n")
print("----------------------")
//end of 6th question

//7th question
var s = "Welcome to iOS Class"
var res=""
var stringWithoutSpace=s.replacingOccurrences(of: " ", with: "")
for char in stringWithoutSpace{
    if res.isEmpty{
        res.append(char)
    }
    else{
        res.append(",\(char)")
    }
}
print("\n"+res,"\n")
print("----------------------")


