//
//  ViewController.swift
//  Mannam_Assignment02
//
//  Created by Sandeep Mannam on 9/12/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var nameOutlet: UITextField!
    
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBTN(_ sender: UIButton) {
        
        let input1 = nameOutlet.text
        
        let input2 = Double(billAmountOutlet.text!) ?? 0;
         
        let input3 = Double(tipPercentageOutlet.text!) ?? 0;
        
        let input4 = Double(input2 * input3)/100
        
        let input5 = input2 + input4
        
        nameLabel.text="Name: "+(input1!)
        billAmountLabel.text="Bill Amount: $\(input2)"
        tipAmountLabel.text="Tip Amount: $\(String(format: "%.2f", input4))"
        totalAmountLabel.text="Total Amount: $\(String(format: "%.2f", input5))"
    }
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        nameOutlet.text=""
        billAmountOutlet.text=""
        tipPercentageOutlet.text=""
        
        nameLabel.text="Name: "
        billAmountLabel.text="Bill Amount: "
        tipAmountLabel.text="Tip Amount: "
        totalAmountLabel.text="Total Amount: "
    }
    
    
}

