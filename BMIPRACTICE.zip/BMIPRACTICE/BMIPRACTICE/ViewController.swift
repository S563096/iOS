//
//  ViewController.swift
//  BMIPRACTICE
//
//  Created by Sandeep Mannam on 11/14/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var heightOL: UITextField!
    
    @IBOutlet weak var weightOL: UITextField!
    var imageName = ""
    var bmi = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func BMIBtn(_ sender: UIButton) {
        
        var height = Double(heightOL.text!)
        
        var weight = Double(weightOL.text!)
        
        bmi = weight! / (height! * height!) * 703
        print(bmi)
        
        if(bmi<=18.4){
            imageName = "underweight"
        }
        else if(bmi>18.5 && bmi<=24.9){
            imageName = "normalweight"
        }
        else if(bmi>25.0 && bmi<=39.9){
            imageName = "overweight"
        }
        else if(bmi>=40.0){
            imageName = "obseweight"
        }
        else{
            imageName = "notfound"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if transition == "resultsegue"{
            var destination = segue .destination as! ResultViewController
            
            destination.height1 = heightOL.text!
            destination.weight1 = weightOL.text!
            destination.result = String (bmi)
            destination.imageName = imageName
            
            heightOL.text = ""
                        weightOL.text = ""
        }
    }
    
}
    




