//
//  ResultViewController.swift
//  BMIPRACTICE
//
//  Created by Sandeep Mannam on 11/14/23.
//

import UIKit


class ResultViewController: UIViewController {
  
    
    @IBOutlet weak var height1OL: UILabel!
    
    @IBOutlet weak var weight1OL: UILabel!
    
    @IBOutlet weak var resultOL: UILabel!
  
    @IBOutlet weak var imageOL: UIImageView!
    
    var height1 = ""
    var weight1 = ""
    var result = ""
    var imageName = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        height1OL.text = height1OL.text! + height1
        
        weight1OL.text = weight1OL.text! + weight1
        
        resultOL.text = resultOL.text! + result
        
        imageOL.image = UIImage(named: "imageName")
        
        var width = imageOL.frame.width
        
        width += 40
        
        var height = imageOL.frame.height
        
        height = height + 40
        
        var x  =  imageOL.frame.origin.x-20
        
        
        var y = imageOL.frame.origin.y-20
        
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 50, animations: {
            self.imageOL.frame = largeFrame
        })
        
        imageOL.image = UIImage(named: imageName)
        func updateAndAnimate(_ imageName : String){
            
            //making the current image opaque.
            UIView.animate(withDuration: 1, animations: {
                self.imageOL.alpha = 0
            })
            
            //Assign the new image with animation and make it transparent. (alpha = 1)
            
            UIView.animate(withDuration: 1, delay:0.5, animations: {
                self.imageOL.alpha = 1
                self.imageOL.image = UIImage(named: imageName)
            })
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
