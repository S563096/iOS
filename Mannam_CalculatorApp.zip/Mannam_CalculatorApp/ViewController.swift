//
//  ViewController.swift
//  Mannam_CalculatorApp
//
//  Created by Sandeep Mannam on 9/20/23.
//

import UIKit

class ViewController: UIViewController {
    var isCorrect = false
    var varNum1:Double=0;
    var varNum2:Double=0;
    var opearator = ""
    var isNotOkay=false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var resultOutlet: UILabel!

    
    @IBAction func buttonAC(_ sender: UIButton) {
        varNum1=0
        varNum2=0
        opearator=""
        resultOutlet.text=""
        isCorrect=false
        isNotOkay=false
    }
    
    @IBAction func buttonC(_ sender: UIButton) {
        resultOutlet.text="0"
        isCorrect=false
    }
    
    @IBAction func buttonChange(_ sender: UIButton) {
        if isCorrect{
            isNotOkay = !isNotOkay
            if isNotOkay{
                resultOutlet.text = "-" + resultOutlet.text!
            }
            else{
                resultOutlet.text!.removeFirst()
            }
        }
    }
    
    @IBAction func buttonDivision(_ sender: UIButton) {
        manageOpe("÷")
    }
    
    @IBAction func buttonSeven(_ sender: UIButton) {
        append(7)
    }
    
    @IBAction func buttonEight(_ sender: UIButton) {
        append(8)
    }
    
    @IBAction func buttonNine(_ sender: UIButton) {
        append(9)
    }
    
    @IBAction func buttonMultiply(_ sender: UIButton) {
        manageOpe("*")
    }
    
    @IBAction func buttonFour(_ sender: UIButton) {
        append(4)
    }
    
    @IBAction func buttonFive(_ sender: UIButton) {
        append(5)
    }
    
    @IBAction func buttonSix(_ sender: UIButton) {
        append(6)
    }
    
    @IBAction func buttonMinus(_ sender: UIButton) {
        manageOpe("-")
    }
    
    @IBAction func buttonOne(_ sender: UIButton) {
        append(1)
    }
    
    @IBAction func buttonTwo(_ sender: UIButton) {
        append(2)
    }
    
    @IBAction func buttonThree(_ sender: UIButton) {
        append(3)
    }
    
    @IBAction func buttonAdd(_ sender: UIButton) {
        manageOpe("+")
        
    }
    
    @IBAction func buttonZero(_ sender: UIButton) {
        append(0)
    }
    
    @IBAction func ButtonPoint(_ sender: UIButton) {
        if isCorrect && !resultOutlet.text!.contains(".") {
            resultOutlet.text! += "."
        }
        else if !isCorrect {
            resultOutlet.text = "0."
            isCorrect=true
        }
        
    }
    
    @IBAction func buttonPercentage(_ sender: UIButton) {
        manageOpe("%")
    }
    
    @IBAction func buttonEquals(_ sender: UIButton) {
        if isCorrect{
            let operator1 = Double(resultOutlet.text!) ?? 0
            
            switch opearator{
            case "+":
                varNum1 += operator1
                
            case "-":
                varNum1 -= operator1
                
            case "*":
                varNum1 *= operator1
                
            case "÷":
                if operator1 != 0 {
                    varNum1 /= operator1
                } else {
                    resultOutlet.text = "Not a number"
                    return
                }
                
            case "%":
                varNum1 = varNum1.truncatingRemainder(dividingBy: operator1)
                
            default:
                break
            }
                resultOutlet.text = formatResult(varNum1)
                
                isCorrect = false
                isNotOkay = false
            }
        }
        //func clearText(){
        //    resultOutlet.text=""
        // }
        func append(_ digit: Int) {
            if isCorrect {
                if resultOutlet.text == "0" || resultOutlet.text == "-0" {
                    if digit != 0 {
                        resultOutlet.text = isNotOkay ? "-" + "\(digit)" : "\(digit)"
                    }
                } else {
                    resultOutlet.text! += "\(digit)"
                }
            } else {
                resultOutlet.text = isNotOkay ? "-" + "\(digit)":"\(digit)"
                isCorrect = true
            }
        }
        func manageOpe(_ operatorSymbol: String) {
            if isCorrect {
                let value = resultOutlet.text!
                varNum1 = Double(value) ?? 0
                isCorrect = false
            }
           opearator = operatorSymbol
            isNotOkay=false
        }

                func formatResult(_ number: Double) -> String {
                    let roundOf = round(number * 100000) / 100000
                    if roundOf.truncatingRemainder(dividingBy: 1) == 0 {
                        return String(format: "%.0f", roundOf)
                    } else {
                        return String(roundOf)
                    }
                }
    }

