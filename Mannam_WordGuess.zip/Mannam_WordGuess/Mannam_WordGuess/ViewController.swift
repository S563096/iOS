//
//  ViewController.swift
//  Mannam_WordGuess
//
//  Created by Sandeep Mannam on 10/18/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var CheckButton: UIButton!
    
    
    @IBOutlet weak var PlayAgain: UIButton!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    //hints with answers in array
    var words = [["PRABHAS","Telugu film industry hero"],["BIRYANI","Famous food in hyderabad"],["DOG","Pet Animal"],["MACBOOK","Apple Device"],["MISSOURI","Maryville located in"]]
    //images names in array
    var wordsimagearray = ["prabhas","biryani","dog","macbook","MISSOURI"]
    var count = 0;
    var word = "";
    var lettersGuessed = ""
    var guessNumCount = 0
    let maxNumFalseGuess = 10
    var correctWordCount = 0
    var remainWordNum = 5
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        CheckButton.isEnabled = false;
        PlayAgain.isHidden = true
        statusLabel.text = ""
        wordsGuessedLabel.text! += "0"
        wordsRemainingLabel.text! += "5"
        totalWordsLabel.text! += String(words.count)
        word = words[count][0]
        hintLabel.text = words[count][1]
        userGuessLabel.text = ""
        updateUnderscores()
    }
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        var letter = guessLetterField.text!
        guessNumCount = guessNumCount + 1
        lettersGuessed = lettersGuessed + letter
        var revealedword = ""
        for l in word{
            
            if lettersGuessed.contains(l){
                revealedword = revealedword + "\(l)"
            }
            else{
                revealedword += "_ "
            }
            
        }
        
        userGuessLabel.text = revealedword
        
        guessLetterField.text = ""
        
        guessCountLabel.text = "You have made \(guessNumCount) guessess"
        
        if userGuessLabel.text!.contains("_") == false{
            correctWordCount = correctWordCount+1
            remainWordNum = remainWordNum-1
        
            PlayAgain.isHidden = false;
            CheckButton.isEnabled = false;
            
            displayImage.image = UIImage(named:wordsimagearray[count])
            guessCountLabel.text = "Wow! you have made \(guessNumCount) guesses to guess the word"
            
            wordsGuessedLabel.text = ""
            wordsGuessedLabel.text! = "Total number of words guessed successfully:" + "\(correctWordCount)"
            
            print(correctWordCount)
            
            print(wordsGuessedLabel.text!)
            wordsRemainingLabel.text! = "Total number of words remaining in  game: " + "\(remainWordNum)"
            
        }
        
        if(guessNumCount > 10){
            
            PlayAgain.isHidden = false
            guessCountLabel.text = "You have used all the available guesses, Please Play Again"
            count -= 1
            
        }
        
        CheckButton.isEnabled = false
        
    }
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        
        PlayAgain.isHidden = true
        displayImage.image = nil
        guessNumCount = 0
        guessCountLabel.text = "You have made \(guessNumCount) guesses"
        lettersGuessed = ""
        count = count+1
        
        if count == words.count{
            
            statusLabel.text = "Congrulations! You are done with the game!"
            displayImage.image = UIImage(named: "alldone")
            userGuessLabel.text = ""
            hintLabel.text = ""
            guessCountLabel.text = ""
            PlayAgain.isHidden = false
            
        }
        
        else{
            
            word = words[count][0]
            hintLabel.text = "Hint: "
            hintLabel.text! += words[count][1]
            CheckButton.isEnabled = true
            userGuessLabel.text = ""
            updateUnderscores()
            
        }
        
        
    }
    
    //for text field
    @IBAction func enterLabelChanged(_ sender: UITextField) {
        
        if(guessLetterField.text!.isEmpty){
            
            CheckButton.isEnabled = false
        }
        else{
            
            CheckButton.isEnabled = true
        }
        
    }
    
    //function to update the underscores
    func updateUnderscores(){
        
        for letter in 0..<word.count{
            
            userGuessLabel.text! += "_ "
            
        }
    }

}

