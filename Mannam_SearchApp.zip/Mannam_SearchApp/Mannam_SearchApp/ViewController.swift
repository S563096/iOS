//
//  ViewController.swift
//  Mannam_SearchApp
//
//  Created by Sandeep Mannam on 10/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var prevButtonOutlet: UIButton!
    
    
    @IBOutlet weak var nextButtonOutlet: UIButton!
    
    
    @IBOutlet weak var stackViewOutlet: UIStackView!
    
    
    
    @IBOutlet weak var resetBtnOL: UIButton!
    
    var imagesArray = [["dhoni","klrahul","Kohli","RohitSharma","Sachin"],
                       ["ak47","akmkalash","sniper","goldgun","pistol"],
                       ["cocacola","dietcoke","pepsi","zevia","fanta"]]
    
    
    var cricketers = ["players","captain","batting","batsmen",
                      "bowling","india"]
    var guns = ["guns","shooting","scope","bullets","load","dangerous"]
    var softdrinks = ["sweet","cold","ice","sugars","liquids"]
    
    var content = 0
    var index = 0
    
    
    
    var contentArray = [["Cricket is a bat-and-ball game played between two teams of eleven players on a field at the centre of which is a 22-yard (20-metre) pitch with a wicket at each end","each comprising two bails balanced on three stumps. The batting side scores runs by striking the ball bowled at one of the wickets with the bat and then running between the wickets"," while the bowling and fielding side tries to prevent this (by preventing the ball from leaving the field, and getting the ball to either wicket) and dismiss each batter "," Means of dismissal include being bowled, when the ball hits the stumps and dislodges the bails,"," and by the fielding side either catching the ball after it is hit by the bat, but before it hits the ground, or hitting a wicket with the ball before a batter can cross the crease in front of the wicket"],
                        ["A gun is a device or ranged weapon designed to propel a projectile using pressure or explosive force."," The projectiles are typically solid, but can also be pressurized liquid ","(e.g. in water guns/cannons), or gas (e.g. light-gas gun). Solid projectiles may be free-flying ","(as with bullets and artillery shells) or tethered ","(as with Tasers, spearguns and harpoon guns)." ],
                        ["Coca-Cola, or Coke, is a carbonated soft drink manufactured by the Coca-Cola Company."," In 2013, Coke products were sold in over 200 countries worldwide.","Fanta is an American-owned German brand of fruit-flavored carbonated soft drinks created by Coca-Cola Deutschland under the leadership of German businessman Max Keith.","There are more than 200 flavors worldwide","Diet Coke is a sugar-free and low-calorie soft drink produced and distributed by the Coca-Cola"]]
    
    
    var topic = -1
    var indexOfNestedArray = -1;
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        prevButtonOutlet.isHidden = true
        nextButtonOutlet.isHidden = true
        resetBtnOL.isHidden = true
        
        resultImage.image = UIImage(named: "Welcome ")
 
    }

    @IBAction func searchButtonAction(_ sender: UIButton) {
        index = 0
        topicInfoText.text = ""
        topicInfoText.isUserInteractionEnabled = true
        if(cricketers.contains(searchTextField.text!)) {
            topic = 0
            indexOfNestedArray = 0
            content = 1
            prevButtonOutlet.isEnabled = false
            nextButtonOutlet.isEnabled = true
            prevButtonOutlet.isHidden = false
            nextButtonOutlet.isHidden = false
            resetBtnOL.isHidden = false
            resultImage.image = UIImage(named: imagesArray[0][0])
            topicInfoText.text = contentArray[0][0]
            
        } else if(guns.contains(searchTextField.text!)) {
            content = 2
            prevButtonOutlet.isEnabled = false
            nextButtonOutlet.isEnabled = true
            stackViewOutlet.isHidden = false
            resultImage.image = UIImage(named: imagesArray[1][0])
            topicInfoText.text = contentArray[1][0]
            
        } else if(softdrinks.contains(searchTextField.text!)) {
            content = 3
            prevButtonOutlet.isEnabled = false
            nextButtonOutlet.isEnabled = true
            stackViewOutlet.isHidden = false
            resultImage.image = UIImage(named: imagesArray[2][0])
            topicInfoText.text = contentArray[2][0]
        } else {
            resultImage.image = UIImage(named: "No search found")
            stackViewOutlet.isHidden = true
            topicInfoText.isUserInteractionEnabled = false
        }
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        index -= 1
        nextButtonOutlet.isEnabled = true
        switch content {
        case 1:
            resultImage.image = UIImage(named: imagesArray[0][index])
            topicInfoText.text = contentArray[0][index]
        case 2:
            resultImage.image = UIImage(named: imagesArray[1][index])
            topicInfoText.text = contentArray[1][index]
        case 3:
            resultImage.image = UIImage(named: imagesArray[2][index])
            topicInfoText.text = contentArray[2][index]
        default:
            print("enter into default")
        }
        
        if(index == 0) {
            prevButtonOutlet.isEnabled = false
        } else {
            prevButtonOutlet.isEnabled = true
        }
    }

    
                       @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        index += 1
                           print(index)
        nextButtonOutlet.isEnabled = true
        prevButtonOutlet.isEnabled = true
                           
                           indexOfNestedArray = indexOfNestedArray + 1
        switch content {
        case 1:
            print(content)
            resultImage.image = UIImage(named: imagesArray[0][indexOfNestedArray])
            topicInfoText.text = contentArray[0][indexOfNestedArray]
            
        case 2:
            print(content)

            resultImage.image = UIImage(named: imagesArray[1][index])
            topicInfoText.text = contentArray[1][index]
        case 3:
            print(content)

            resultImage.image = UIImage(named: imagesArray[2][index])
            topicInfoText.text = contentArray[2][index]
        default:
            print("enter into default")
        }
        
        if(index == imagesArray[0].count - 1) {
            nextButtonOutlet.isEnabled = false
        } else {
            nextButtonOutlet.isEnabled = true
        }
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        searchTextField.text = ""
        index = 0
        utilUIElements()
        
    }
    
        @IBAction func EditableTextField(_ sender: UITextField) {
            
            if searchTextField.text!.isEmpty {
                searchButton.isEnabled = false
            } else {
                searchButton.isEnabled = true
            }
        }
 
    
        func utilUIElements() {
            searchButton.isEnabled = false
            resultImage.image = UIImage(named: "Welcome")
            topicInfoText.text = ""
            topicInfoText.isUserInteractionEnabled = false
            stackViewOutlet.isHidden = true
            content = 0
        }
    
    
}
                       

