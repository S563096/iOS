import UIKit
//1
var greeting = "Hello, playground"
print("hi",10,12.25)

//2
// print statement using string interpolation
var pl = "s"
print("hello \(pl)")

//3
var a = 2
print("i am \(a) years old ,by next 2 years my age will be \(a * 2)")

//4  \r to come single sentance jin new line
print("hello all,\rwelcome to home")

//5
let welcomeMsg : String = "Hello"
print(welcomeMsg, "All")

//7 to get
print("hello" , terminator : "  ")
print("jack")

//8
print(1,2,3,4,5,6,7, separator  : "-")
print("hi")

//9
var s = "m"
s = "a"
print(s)

//10
let pi = 3.14
print(pi)

//11 explict declaration
var age : Int = 23
print(age * 2)

//12
var ss = "h"
print(ss)
print("i")

//13
var httpError = (errorCode : 404 , errorMessage : "page not found")
print(httpError)
print(httpError.errorCode , terminator: ": ")
print(httpError.errorMessage)

//14
var o = (x : 0 , y : 0)
var point = o
print(point)

//15
var fn : Int = 10
var ln : Int = 25
print(ln / fn)

//16
var four = 4
var final = -four
print(final)

//17

var n1 = (1,2)
var n2 = (2,3)
print(n1 < n2)

//18 control flow
var m = 45
if m > 50 {
    print("the student had passed with \(m) marks")
}else{
    print("the student had managed to get \(m) marks")
}

//19
var input = -10
if (input > 0) {
    print("\(input) is a positive number")
}else if(input<0) {
    print("\(input) is a negative number")
    if(input%2 == 0){
        print("\(input) is a negative even number")
    }else{
        print("\(input) is a 0")
    }
}

//20

var stars = 65
if(stars >= 90) {
    print("you are a pro menber")
}
else if(stars>=78 && stars<90){
    print("you are a gold member")
}
else if(stars>=65 && stars<78){
    print("vip mem")
}

//21 switch
let alphabet:Character="a"
switch alphabet {
    case "a","A":
        print("it is a or A")
case "b","B":
    print("it is a b or B")
case "c","C":
    print("it is c or C")
default:
    print("none of the cases are executed bove")
    <#code#>
}

//22 switch

var check:Character="i"
switch check{
case "a","e","i","o","u":
    print("\(check)~",terminator: "")
    print("done")
case "A","E","I","O","U":
    print("it is big ")
default:
    print("none of the ebove")
}

//23 for loop
var n:Int = 5
for index in 1...5 {
    print("\(index) * \(n) = \(index*n)")
}

//24
var totalNum:Int = 5
var sum:Int = 0
for i in 1...totalNum {
    print("\(i)")
    sum += i
}
print("the sum of first \(totalNum) is \(sum)")

//26
var coreLang = ["javc","swift","asp.net"]
for i in 0..<coreLang.count{
    print("\(coreLang)")
}

var m1 = true
var s1:Int = 10
var c1 = 0
for i in 1..<s1 {
    c1 += 1
    if m1{
        if c1 > 3 {
            print("won \(s1 - 2)$")
            c1 = 0
            break
        }
        else{
            if(c1 > 8){
                print("won \(s1 - 8)$")
            }
        }
    }
}

//27
func greetUser(){
    print("welcome user")
}

greetUser();

//28
func greet()->String{
    var nameee = "swift"
    return "hello "+nameee
}
print(greet())

var fact = "Swift is a type safe language"

print(fact.count)

print(fact[fact.startIndex])
print(fact[fact.index(before: fact.endIndex)])

print(fact[fact.index(after: fact.startIndex)])

print(fact[fact.index(fact.startIndex,offsetBy: 6)])

print(fact.split(separator: ","))
