//
//  Universities.swift
//  Mannam_UniversityApp
//
//  Created by Sandeep Mannam on 11/16/23.
//

import Foundation

struct Universities {
    var domain = ""
    var list : [UniversityList] = []
    
}
struct UniversityList{
    var clgName : String = ""
    var clgImage  = ""
    var clgInfo  = ""
}

var domain1 = Universities(domain : "Computer Science",list: [UniversityList(clgName : "Harvard University",clgImage: "Harvard",clgInfo: "Harvard University is a private Catholic university in Massachusets, Cambridge. Harvard University has approximately 4,500 students and 46,000 alumni. Its intercollegiate athletics include 18 athletic programs for men and women competing at the NCAA Division II level. "),UniversityList(clgName : "The University of Texas at Arlington",clgImage: "UTA",clgInfo: "The University of Texas at Arlington is a public research university in Arlington, Texas. The university was founded in 1895 and was in the Texas A&M University System for several decades until joining the University of Texas System in 1965."),UniversityList(clgName : "University of Houston",clgImage: "UH",clgInfo: "The University of Houston is a public research university in Houston, Texas. Founded in 1927, UH is a member of the University of Houston System and the third-largest university in Texas with over 47,000 students.")])

var domain2 = Universities(domain : "Data Science",list: [UniversityList(clgName : " Stanford University",clgImage: "Stanford",clgInfo: "University of Stanford is a private institution that was founded in 1890. It has a total undergraduate enrollment of 7,526 (fall 2021), its setting is urban, and the campus size is 217 acres. It utilizes a quarter-based academic calendar. University of Stanford's ranking in the 2022-2023 edition of Best Colleges is National Universities, #6. Its tuition and fees are $62,940."),UniversityList(clgName : "Duke University",clgImage: "Duke",clgInfo: "Duke University is a private institution that was founded in 1838. It has a total undergraduate enrollment of 6,883 (fall 2021), its setting is suburban, and the campus size is 8,693 acres. It utilizes a semester-based academic calendar. Duke University's ranking in the 2022-2023 edition of Best Colleges is National Universities, #10. Its tuition and fees are $63,054.")])

var domain3 = Universities(domain : "Information Technology",list: [UniversityList(clgName : "University of Cincinnati",clgImage: "UCC",clgInfo: "The University of Cincinnati is a public research university in Cincinnati, Ohio. Founded in 1819 as Cincinnati College, it is the oldest institution of higher education in Cincinnati and has an annual enrollment of over 44,000 students, making it the second largest university in Ohio."),UniversityList(clgName : "Golden Gate University - San Francisco",clgImage: "GGU",clgInfo: "Founded in 1901 in San Francisco, California, Golden Gate University (GGU) focuses on graduate and undergraduate education in business, law, taxation, and accounting. A private, nonprofit institution of higher learning, GGU grants a master of science in information technology management, fitting for learners looking to extend and further develop their expertise in the field.")])

var domain4 = Universities(domain : "Information Systems",list: [UniversityList(clgName : "Yale University",clgImage: "YU",clgInfo: "Yale University is a private Ivy League research university in New Haven, Connecticut. Founded in 1701, Yale is the third-oldest institution of higher education in the United States and one of the nine colonial colleges chartered before the American Revolution."),UniversityList(clgName : "NORTWEST MISSOURI STATE UNIVERSITY",clgImage: "NWMSU",clgInfo: "Northwest Missouri State University is a public university in Maryville, Missouri. It has an enrollment of about 8,505 students. Founded in 1905 as a teachers college, its campus is based on the design for Forest Park at the 1904 St. Louis World's Fair and is the official Missouri State Arboretum."),UniversityList(clgName : "University of Central Missouri",clgImage: "UCM",clgInfo: "The University of Central Missouri is a public university in Warrensburg, Missouri. In 2019, enrollment was 11,229 students from 49 states and 59 countries on its 1,561-acre campus. UCM offers 150 programs of study, including 10 pre-professional programs, 27 areas of teacher certification, and 37 graduate programs.")])


var domains = [domain1, domain2, domain3, domain4]

