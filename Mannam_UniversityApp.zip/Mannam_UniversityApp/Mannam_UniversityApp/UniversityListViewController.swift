//
//  UniversityListViewController.swift
//  Mannam_UniversityApp
//
//  Created by Sandeep Mannam on 11/16/23.
//

import UIKit
class college{
    var universityName : String?
    var universityImage : String?
    var universityInfo : String?
    
    init(universityName : String,universityImage : String,universityInfo : String){
        self.universityName = universityName;
        self.universityImage = universityImage;
        self.universityInfo = universityInfo;
    }
}
var image_name = ""
var desc = ""
var uni_name = ""
var universiity = [college]()

class UniversityListViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return domains[0].list.count
    }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        
        cell.textLabel?.text = universities?.list[indexPath.row].clgName
        
        uni_name = (universities?.list[indexPath.row].clgName)!
        
        image_name = (universities?.list[indexPath.row].clgImage)!
        
        desc = (universities?.list[indexPath.row].clgInfo)!
        var output = college(universityName: uni_name, universityImage: image_name, universityInfo: desc)
        universiity.append(output)
        print(image_name+"----------------------------"+desc+uni_name)
        
        return cell
    }
    
    
    @IBOutlet weak var universityListTableView: UITableView!
    var universities : Universities?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        universityListTableView.delegate = self
        universityListTableView.dataSource = self

        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           let transition = segue.identifier
        if(transition == "universityInfoSegue"){
            let destination = segue.destination as! UniversityInfoViewController
            destination.university = universiity[(universityListTableView.indexPathForSelectedRow?.row)!]
                          //destination.university = l
            //destination.lab = tableView(UITableView, cellForRowAt: IndexPath)
            //destination.nam = co
        }
        }

}
