//
//  UniversityInfoViewController.swift
//  Mannam_UniversityApp
//
//  Created by Sandeep Mannam on 11/16/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    
    var university : college?
        var imgInfo = ""
        var labInfo = ""
        var nameInfo = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = university?.universityName
                print(university)
        universityInfoOutlet.isHidden = true

        // Do any additional setup after loading the view.
    }
    

    
    override func viewDidAppear(_ animated: Bool) {
        universityImageViewOutlet.image = UIImage(named:(university?.universityImage)!)
        universityImageViewOutlet.frame.origin.x = view.frame.maxX
        UIView.animate(withDuration: 1, animations: {
            self.universityImageViewOutlet.center.x = self.view.center.x})
        
    }
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    
    @IBAction func showInfoAction(_ sender: Any) {
        universityInfoOutlet.isHidden = false
        universityInfoOutlet.text! = (university?.universityInfo)!
        print(nameInfo)
        
    }
    
  

}
